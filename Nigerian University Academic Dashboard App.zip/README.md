# Nigerian University Academic Survival Dashboard

A GPA/CGPA, coursework, attendance, deadline, SIWES/IT and final-year-project
tracker for Nigerian university students. Runs entirely in your browser -
no internet connection needed once it's open, no server, nothing sent
anywhere.

## Quickest way to use it

Double-click **index.html**. It opens in your browser and works fully -
create an account, enter your data, close the tab, come back later and
it's all still there. That's it; the other files in this folder are only
needed if you want the extra "install as an app" behaviour below.

## Getting the "Install app" button (optional)

Browsers only offer to install a site as an app when it's served over
`http://` or `https://`, not when opened as a local file. If you want the
"Install app" button, the home-screen icon, and offline caching, host this
folder somewhere - all of these are free:

**GitHub Pages**
1. Create a new GitHub repository and upload all the files in this folder.
2. Go to Settings -> Pages -> set Source to your main branch.
3. Open the URL GitHub gives you - you'll see an install icon in the
   browser's address bar (desktop) or an "Install app" button inside the
   dashboard's sidebar (mobile).

**Netlify**
1. Go to netlify.com, drag this whole folder onto the "Deploy manually"
   drop zone.
2. Open the URL it gives you.

**Vercel, Cloudflare Pages, or any static web host** work the same way -
upload the folder, open the URL.

On iPhone/iPad (Safari), "installing" is done via Share -> Add to Home
Screen once the site is hosted at a URL.

## Accounts

This app has its own sign-in so more than one person can use the same
device/browser without seeing each other's data - useful if you're
sharing a family computer or a cyber cafe machine, or you just want a
password on your own academic records.

Read this before you rely on it:
- **There is no server.** Accounts and passwords are created and checked
  entirely inside your browser. Nothing is sent to Anthropic, to us, or to
  anyone else.
- **Accounts are local to one browser, on one device.** Signing up on your
  phone does not create an account you can use on your laptop. Each
  browser/device keeps its own separate list of accounts.
- **There's no password reset.** If you forget your password, there's no
  "forgot password" email - because there's no email, no server, no way
  for anyone (including you) to look it up. Your only way back in is to
  create a new account and re-enter your data, or restore from an export
  (see below).
- **It keeps out casual snooping, not determined attackers.** Passwords
  are hashed before they're stored, but anyone with access to your actual
  browser profile/device and enough technical knowledge could get at the
  underlying data. Don't reuse an important password here, and don't
  store anything you wouldn't want a technically capable person with
  access to your device to see.

## Moving your data / backing it up

Because there's no cloud sync, **Settings -> Your account -> Export my
data** is the only way to move your records to another device or browser,
or to keep a backup. It downloads one `.json` file with everything -
courses, GPA, deadlines, all of it. Use **Import data** on the new
device/browser to load it back in.

Export regularly, the same way you'd back up any file you care about -
especially before clearing your browser's site data, switching browsers,
or getting a new phone/laptop.

## Files in this folder

| File | Purpose |
|---|---|
| `index.html` | The app itself - everything runs from this one file. |
| `manifest.json` | Tells the browser the app's name/icon/colors so it can be installed. Only used when hosted. |
| `sw.js` | Service worker - caches the app so it loads instantly and works offline once hosted and visited once. |
| `icon-192.png`, `icon-512.png` | App icons used for the home-screen/install icon. |

## Grading scales supported

Switch between the 5-Point scale (UI, UNILAG, OAU, ABU, UNN, UNIBEN and
most public universities) and the 4-Point scale in Settings - every
calculation in the app updates immediately.
